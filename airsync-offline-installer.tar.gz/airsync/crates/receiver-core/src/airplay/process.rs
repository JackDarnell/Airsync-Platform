// Process management for shairport-sync
// TODO: Implement in next iteration
